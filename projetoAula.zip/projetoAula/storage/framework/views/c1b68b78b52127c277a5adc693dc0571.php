
<?php $__env->startSection('conteudo'); ?>
<h1>Lista de Produtos</h1>
<div class="table-responsive"> <table class="table table-striped"> <thead>
    <tr>
    <th>ID</th>
    <th>Nome</th>
    <th>Descrição</th>
    <th>Quantidade</th>
    <th>Valor</th>
    <th>Categoria</th>
    <th>Estado</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($produto->id); ?></td>
    <td><?php echo e($produto->nome); ?></td>
    <td><?php echo e($produto->descricao); ?></td>
    <td><?php echo e($produto->qtdeEstoque); ?></td>
    <td><?php echo e($produto->valor); ?></td>
    <td><?php echo e($produto->categoria); ?></td>
    <td><?php echo e($produto->estadoOrigem); ?></td>
    <td>
        <a class="btn btn-warning" href="<?php echo e(route('produto.atualiza', ['id' => $produto->id])); ?>">Alterar</a>
        <a class="btn btn-danger" href="#" onclick="exclui(<?php echo e($produto->id); ?>)">Excluir</a> </td> </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
            <a class="btn btn-primary" href="<?php echo e(route('produtos.cadastro')); ?>"> Cadastrar Novo </a>
</div>
<script>
    function exclui(id) {
        if (confirm('Deseja excluir o produto de id: ' + id + '?')) {
            location.href = '/produto/excluir/' + id;
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoAula\resources\views/produtos/index.blade.php ENDPATH**/ ?>