<?php $__env->startSection('alterar'); ?>
    <h1>Alteração de Usuário</h1>
    <form method="post" action="<?php echo e(route('usuario.alterar' , ['id' => $u->id])); ?>">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="text" name="nome" placeholder="Nome" value="<?php echo e($u ->nome); ?>">
        <input type="text" name="login" placeholder="Login" value="<?php echo e($u ->login); ?>">
        <input type="text" name="senha" placeholder="Senha" value="<?php echo e($u ->senha); ?>">
        <input type="submit" value="Enviar">
    </form> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoAula\resources\views/usuarios/alterar.blade.php ENDPATH**/ ?>