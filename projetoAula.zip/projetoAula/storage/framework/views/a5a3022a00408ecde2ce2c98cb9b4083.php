<?php $__env->startSection('login'); ?>

<div class="container mt-5">
    <form action="<?php echo e(route('login')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-header">
                <h3 class="text-center">Login</h3>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label for="usuario">Nome do Usuário</label>
                    <input type="text" class="form-control" id="usuario" placeholder="Digite seu usuário" name="login">
                </div>

                <div class="form-group">
                    <label for="senha">Senha</label>
                    <input type="password" name="senha" id="senha" placeholder="Digite sua senha" class="form-control">
                </div>

                <button type="submit" class="btn btn-primary btn-block">Entrar</button>
            </div>
        </div>
    </form>
</div>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<?php /**PATH C:\xampp\htdocs\projetoAula\resources\views/login.blade.php ENDPATH**/ ?>