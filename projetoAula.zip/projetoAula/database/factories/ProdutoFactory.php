<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Produto;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Produto>
 */
class ProdutoFactory extends Factory
{
    protected $model = Produto::class;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {

        $produtos = [
            'Videogame', 'Carro', 'Celular', 'Camiseta', 'Sapato',
            'Livro', 'Mesa', 'Cadeira', 'Relógio', 'Bolsa',
            'Guitarra', 'Computador', 'Teclado', 'Mouse', 'Fone de Ouvido',
            'Óculos de Sol', 'Mochila', 'Televisão', 'Câmera', 'Headset',
            'Chapéu', 'Bicicleta', 'Sofá', 'Tênis', 'Perfume',
            'Jogo de Tabuleiro', 'Escova de Dentes', 'Maquiagem', 'Colchão', 'Cafeteira',
            'Mala de Viagem', 'Ventilador', 'Luminária', 'Caneca', 'Panela',
            'Bicicleta Ergométrica', 'Impressora', 'Máquina de Lavar Roupa', 'Aparelho de Som', 'Escultura',
            'Quadro', 'Ferramenta Elétrica', 'Kit de Churrasco', 'Cadeira de Praia', 'Chinelo',
            'Notebook', 'Tablet', 'Brinquedo de Pelúcia', 'Bola de Futebol', 'Colar',
            'Smartwatch', 'Pijama', 'Guarda-chuva', 'Caneta', 'Caixa de Som Bluetooth',
            'Carregador Portátil', 'Laptop', 'Tênis de Mesa', 'Frigobar', 'Squeeze',
            'Piano Digital', 'Cama Box', 'Cadeado', 'Pulseira', 'Bateria de Cozinha',
            'Edredom', 'Balde de Gelo', 'Kit de Pintura', 'Relógio Despertador', 'Aquecedor',
            'Cabo USB', 'Cortina', 'Kit de Maquiagem', 'Escova de Cabelo', 'Jogo de Copos',
            'Secador de Cabelo', 'Cofre', 'Pulseira Fitness', 'Vaso Decorativo', 'Aromatizador de Ambiente',
            'Caixa de Ferramentas', 'Lixeira', 'Máquina de Café', 'Carrinho de Bebê', 'Tapete',
            'Almofada', 'Jogo de Panelas', 'Faca de Cozinha', 'Telescópio', 'Corda de Pular',
            'Tapete de Yoga', 'Kit de Costura', 'Hidratante Corporal', 'Creme Facial', 'Sabonete',
            'Cadeira Gamer', 'Monitor de Computador', 'Lanterna', 'Patinete Elétrico', 'Aspirador de Pó',
        ];

        $categorias = [
            'Eletrônicos', 'Roupas', 'Acessórios', 'Alimentos', 'Livros', 'Brinquedos',
            'Ferramentas', 'Cosméticos', 'Móveis', 'Esportes', 'Jogos', 'Instrumentos Musicais',
            'Artigos de Decoração', 'Jardinagem', 'Automotivo', 'Papelaria', 'Pet Shop'
        ];
        

        return [
            'nome' => $this->faker->randomElement($produtos),
            'descricao' => $this->faker->text($maxNbChars = 200),
            'qtdeEstoque' => $this->faker->randomDigitNotNull,
            'valor' => $this->faker->numberBetween($min = 1000, $max = 9000),
            'categoria' => $this->faker->randomElement($categorias),
            'estadoOrigem' => $this->faker->stateAbbr,
        ];
    }
}