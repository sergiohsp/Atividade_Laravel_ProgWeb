<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Produto;

class ProdutoController extends Controller
{
    //
    public function index(){

        $produtos = produto::all();
        return view("produtos.index",compact("produtos"));

    }

    public function cadastro(){
        return view("produtos.cadastro");
    }

    public function novo(Request $req){
        $nome = $req->nome;
        $descricao = $req->descricao;
        $quantidade = $req->quantidade;
        $valor = $req->valor;
        $categoria = $req->categoria;
        $estadoOrigem = $req->estadoOrigem;


        $produto = new Produto();
        $produto->nome = $nome;
        $produto->descricao = $descricao;
        $produto->qtdeEstoque = $quantidade; 
        $produto->valor = $valor;
        $produto->categoria = $categoria;
        $produto->estadoOrigem = $estadoOrigem; 
        
        if($produto->save()){
            $mensagem = "Produto $nome cadastrado com sucesso";
        }else{
            $mensagem = "Não foi possível cadastrar o produto";
        }
        return redirect()->route("produtos.index"); 
    }

    public function telaAlteracao($id){
        $produto = Produto::find($id); // buscando pelo id
        return view("produtos.alterar", ["p" => $produto]);
    }

    public function alterar(Request $req, $id){
        $nome = $req->input("nome");
        $descricao = $req->input("descricao");
        $quantidade = $req->input("quantidade");
        $valor = $req->input("valor");
        $categoria = $req->input("categoria");
        $estadoOrigem = $req->input("estadoOrigem");

        $produto = Produto::find($id);
        $produto->nome = $nome;
        $produto->descricao = $descricao;
        $produto->qtdeEstoque = $quantidade; 
        $produto->valor = $valor;
        $produto->categoria = $categoria;
        $produto->estadoOrigem = $estadoOrigem; 

        if ($produto->save()){
            $msg = "Produto atualizado com sucesso";
        }else{
            $msg = "Erro ao atualizar Produto";
        }
        return view("produtos.resultado", ["mensagem" => $msg]);
    }

    public function excluir($id){
        $produto = Produto::find($id);
        
        if($produto->delete()){ 
            $msg = "Pruduto excluído com sucesso";
        }else{
            $msg = "Erro para Excluir o Produto";
        }
        return view("produtos.resultado", ["mensagem"=> $msg]);
    }

}
