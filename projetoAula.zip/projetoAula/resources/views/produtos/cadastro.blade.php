@extends('layouts.app')
@section('cadastro')
    <div class="container mt-5">
        <h1 class="mb-4">Cadastro de Produto</h1>
        <form action="{{ route('produtos.novo')}}" method="post" class="mb-4">
            @csrf

            <div class="form-group">
                <input type="text" name="nome" class="form-control" placeholder="Nome" required>
            </div>
            <br>
            <div class="form-group">
                <input type="text" name="descricao" class="form-control" placeholder="Descrição" required>
            </div>
            <br>
            <div class="form-group">
                <input type="text" name="quantidade" class="form-control" placeholder="Quantidade" required>
            </div>
            <br>
            <div class="form-group">
                <input type="text" name="valor" class="form-control" placeholder="Valor" required>
            </div>
            <br>
            <div class="form-group">
                <input type="text" name="categoria" class="form-control" placeholder="Categoria" required>
            </div>
            <br>
            <div class="form-group">
                <label for="estadoOrigem">Estado de Origem:</label>
                <select name="estadoOrigem" id="estadoOrigem" class="form-control" required>
                    <option value="acre">AC</option>
                    <option value="alagoas">AL</option>
                    <option value="amapa">AP</option>
                    <option value="amazonas">AM</option>
                    <option value="bahia">BA</option>
                    <option value="ceara">CE</option>
                    <option value="distritoFederal">DF</option>
                    <option value="espiritoSanto">ES</option>
                    <option value="goias">GO</option>
                    <option value="maranhao">MA</option>
                    <option value="matoGrosso">MT</option>
                    <option value="matoGrossoSul">MS</option>
                    <option value="minasGerais">MG</option>
                    <option value="para">PA</option>
                    <option value="paraiba">PB</option>
                    <option value="parana">PR</option>
                    <option value="pernambuco">PE</option>
                    <option value="piaui">PI</option>
                    <option value="rioJaneiro">RJ</option>
                    <option value="rioGrandeNorte">RN</option>
                    <option value="rioGrandeSul">RS</option>
                    <option value="rondonia">RO</option>
                    <option value="roraima">RR</option>
                    <option value="santaCatarina">SC</option>
                    <option value="saoPaulo">SP</option>
                    <option value="sergipe">SE</option>
                    <option value="tocantins">TO</option>
                </select>
            </div>
            <br>
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
    </div>
@endsection
