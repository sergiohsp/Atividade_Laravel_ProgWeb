@extends('layouts.app')
@section('conteudo')
<h1>Lista de Produtos</h1>
<div class="table-responsive"> <table class="table table-striped"> <thead>
    <tr>
    <th>ID</th>
    <th>Nome</th>
    <th>Descrição</th>
    <th>Quantidade</th>
    <th>Valor</th>
    <th>Categoria</th>
    <th>Estado</th>
    </tr>
    </thead>
    <tbody>
    @foreach ($produtos as $produto)
    <tr>
    <td>{{ $produto->id }}</td>
    <td>{{ $produto->nome }}</td>
    <td>{{ $produto->descricao }}</td>
    <td>{{ $produto->qtdeEstoque }}</td>
    <td>{{ $produto->valor }}</td>
    <td>{{ $produto->categoria }}</td>
    <td>{{ $produto->estadoOrigem }}</td>
    <td>
        <a class="btn btn-warning" href="{{route('produto.atualiza', ['id' => $produto->id]) }}">Alterar</a>
        <a class="btn btn-danger" href="#" onclick="exclui({{ $produto->id }})">Excluir</a> </td> </tr>
            @endforeach
            </tbody>
            </table>
            <a class="btn btn-primary" href="{{ route('produtos.cadastro')}}"> Cadastrar Novo </a>
</div>
<script>
    function exclui(id) {
        if (confirm('Deseja excluir o produto de id: ' + id + '?')) {
            location.href = '/produto/excluir/' + id;
        }
    }
</script>
@endsection